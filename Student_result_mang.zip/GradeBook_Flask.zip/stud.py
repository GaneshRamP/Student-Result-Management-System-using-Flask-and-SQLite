from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Initialize database
def init_db():
    with sqlite3.connect("students.db") as conn:
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            subject TEXT NOT NULL,
            marks INTEGER NOT NULL
        )
        ''')
        conn.commit()

# Home page - Display all results
@app.route('/')
def index():
    with sqlite3.connect("students.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM results")
        results = cursor.fetchall()
    return render_template("index.html", results=results)

# Add new student result
@app.route('/add', methods=['POST'])
def add_result():
    try:
        student_name = request.form['student_name']
        subject = request.form['subject']
        marks = int(request.form['marks'])  # Convert to integer

        with sqlite3.connect("students.db") as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO results (student_name, subject, marks) VALUES (?, ?, ?)", 
                           (student_name, subject, marks))
            conn.commit()
        return redirect('/')
    except Exception as e:
        return f"Error: {e}"

# Delete a result
@app.route('/delete/<int:result_id>')
def delete_result(result_id):
    try:
        with sqlite3.connect("students.db") as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM results WHERE id=?", (result_id,))
            conn.commit()
        return redirect('/')
    except Exception as e:
        return f"Error: {e}"

# Run the app
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
